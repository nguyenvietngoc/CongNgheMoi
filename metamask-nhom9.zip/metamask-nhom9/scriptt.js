let accounts = [];
let currentId = 1;

// Xử lý thêm và cập nhật account
document.getElementById("accountForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const accountId = document.getElementById("accountId").value;

  if (accountId) {
    // Cập nhật account
    const account = accounts.find((acc) => acc.id == accountId);
    account.username = username;
    account.email = email;
    document.getElementById("submitButton").innerText = "Add Account";
  } else {
    // Thêm account mới
    accounts.push({ id: currentId++, username, email });
  }

  document.getElementById("accountForm").reset();
  document.getElementById("accountId").value = "";
  renderAccounts();
});

// Hiển thị danh sách account
function renderAccounts() {
  const accountList = document.getElementById("accountList");
  accountList.innerHTML = accounts
    .map(
      (account) => `
      <tr>
        <td>${account.id}</td>
        <td>${account.username}</td>
        <td>${account.email}</td>
        <td class="actions">
          <button onclick="editAccount(${account.id})">Edit</button>
          <button onclick="deleteAccount(${account.id})">Delete</button>
        </td>
      </tr>
    `
    )
    .join("");
}

// Xóa account
function deleteAccount(id) {
  accounts = accounts.filter((account) => account.id !== id);
  renderAccounts();
}

// Sửa account
function editAccount(id) {
  const account = accounts.find((acc) => acc.id === id);
  document.getElementById("username").value = account.username;
  document.getElementById("email").value = account.email;
  document.getElementById("accountId").value = account.id;
  document.getElementById("submitButton").innerText = "Update Account";
}

// Hiển thị ban đầu
renderAccounts();
